To play, simply double click the "SuperSpacePirate.exe"

Please report any bugs or issues on itch.io

Thank you for playing!!!